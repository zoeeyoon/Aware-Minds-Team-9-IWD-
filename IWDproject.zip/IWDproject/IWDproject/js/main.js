jQuery(document).ready(function ($) {
  "use strict";

  $("#form-submit .date").datepicker({});

  var owl = $("#owl-testimonial");

  owl.owlCarousel({
    pagination: true,
    paginationNumbers: false,
    autoPlay: 6000, //Set AutoPlay to 3 seconds
    items: 1, //10 items above 1000px browser width
    itemsDesktop: [1000, 1], //5 items between 1000px and 901px
    itemsDesktopSmall: [900, 1], // betweem 900px and 601px
    itemsTablet: [600, 1], //2 items between 600 and 0
    itemsMobile: false, // itemsMobile disabled - inherit from itemsTablet option
  });

  $(".recommendedgroup > div").hide();
  $(".recommendedgroup > div:first-of-type").show();
  $(".tabs a").click(function (e) {
    e.preventDefault();
    var $this = $(this),
      tabgroup = "#" + $this.parents(".tabs").data("recommendedgroup"),
      others = $this.closest("li").siblings().children("a"),
      target = $this.attr("href");
    others.removeClass("active");
    $this.addClass("active");
    $(tabgroup).children("div").hide();
    $(target).show();
  });

  $(".weathergroup > div").hide();
  $(".weathergroup > div:first-of-type").show();
  $(".tabs a").click(function (e) {
    e.preventDefault();
    var $this = $(this),
      tabgroup = "#" + $this.parents(".tabs").data("weathergroup"),
      others = $this.closest("li").siblings().children("a"),
      target = $this.attr("href");
    others.removeClass("active");
    $this.addClass("active");
    $(tabgroup).children("div").hide();
    $(target).show();
  });

  $(".tabgroup > div").hide();
  $(".tabgroup > div:first-of-type").show();
  $(".tabs a").click(function (e) {
    e.preventDefault();
    var $this = $(this),
      tabgroup = "#" + $this.parents(".tabs").data("tabgroup"),
      others = $this.closest("li").siblings().children("a"),
      target = $this.attr("href");
    others.removeClass("active");
    $this.addClass("active");
    $(tabgroup).children("div").hide();
    $(target).show();
  });

  $(".pop-button").click(function () {
    $(".pop").fadeIn(300);
  });

  $(".pop > span").click(function () {
    $(".pop").fadeOut(300);
  });

  $(window).on("scroll", function () {
    if ($(window).scrollTop() > 100) {
      $(".header").addClass("active");
    } else {
      //remove the background property so it comes transparent again (defined in your css)
      $(".header").removeClass("active");
    }
  });

  /************** Mixitup (Filter Projects) *********************/
  $(".projects-holder").mixitup({
    effects: ["fade", "grayscale"],
    easing: "snap",
    transitionSpeed: 400,
  });
});

// Get a reference to the copy link element

// Add a click event listener to the link
document.addEventListener("DOMContentLoaded", function () {
  const copyLinkButton = document.getElementById("copyLink");
  const copyLink1Button = document.getElementById("copylink1");

  copyLinkButton.addEventListener("click", function (event) {
    event.preventDefault();
    const linkToCopy = "localhost/iwdproject/signup.php";
    copyToClipboard(linkToCopy);
  });

  copylink1.addEventListener("click", function (event) {
    event.preventDefault();
    const linkToCopy1 = "localhost/iwdproject/signup.php";
    copyToClipboard(linkToCopy1);
  });

  function copyToClipboard(text) {
    const tempInput = document.createElement("input");
    tempInput.style.position = "absolute";
    tempInput.style.left = "-9999px";
    tempInput.value = text;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand("copy");
    document.body.removeChild(tempInput);
    alert("Link copied to clipboard!");
  }
});

function move(targetId) {
  var elem = document.getElementById(targetId);
  var width = 10;
  var id = setInterval(frame, 10);

  function frame() {
    if (width >= 100) {
      clearInterval(id);
    } else {
      width++;
      elem.style.width = width + "%";
      elem.innerHTML = width + "%";
    }
  }
}

// Get all buttons with the class "start-button"
var buttons = document.getElementsByClassName("white-button");

// Attach the move() function to each button using a loop
for (var j = 0; j < buttons.length; j++) {
  buttons[j].addEventListener("click", function (event) {
    var targetId = event.target.getAttribute("data-target");
    move(targetId);
  });
}
//Pop up notification
window.onload = function () {
  var popupOverlay = document.getElementById("popupOverlay");
  var closePopupButton = document.getElementById("closePopup");

  // Show the popup automatically when the page loads
  popupOverlay.style.display = "flex";

  // Close the popup when the "Close" button is clicked
  closePopupButton.addEventListener("click", function () {
    popupOverlay.style.display = "none";
  });
};
