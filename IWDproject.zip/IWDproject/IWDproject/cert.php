<!DOCTYPE html>
<html>
<head>
  <title>Certificate of Completion</title>
  <style>
    body {
      text-align: center;
      margin: 10px;
      padding: 0;
    }
    form {
      font-size: 20px;
      padding: 30px;
      border: 2px solid grey;
      max-width: 500px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    input[type="text"] {
      width: 100%;
      padding: 10px;
      margin: 10px;
      font-size: 18px;
      box-sizing: border-box;
    }
    button {
      margin-top: 20px;
      padding: 10px 20px;
      font-size: 18px;
      background-color: grey;
      color: black;
      border: none;
    }
    .certificate {
      border: 10px double #333;
      border-width: 20px;
      padding: 20px;
      max-width: 980px;
      margin: 20px auto;
      background-color: #D4E2D4;
      font-size: 20px;
    }
    h1 {
      font-family: "Times New Roman", Times, serif;
      font-size: 70px;
      padding-top: 40px;
    }
    h3 {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 70px;
    }
    p {
      font-size: 20px;
    }
    .message {
      font-size: 20px;
    }
  </style>
</head>
<body>
  <?php
  $recipientName = "";
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recipientName = $_POST["recipientName"];
  }
  ?>
  
  <?php if (empty($recipientName)) { ?>
    <form method="post">
      <label for="recipientName">Enter Your Name:</label>
      <input type="text" name="recipientName" id="recipientName" required>
      <button type="submit">Submit</button>
    </form>
  <?php } else { ?>
    <div class="certificate">
      <h1>Certificate of Completion</h1>
      <p>This is to certify that</p>
      <h3><?php echo $recipientName; ?></h3>
      <p>has successfully completed the Dementia Awareness course and is awarded with this certificate.</p>
      <p style="font-weight:bold">Aware Minds</p>
    </div>

    <p class="message">Congratulations, what's next? Screenshot your certificate to save it.</p>
  <?php } ?>
</body>
</html>
