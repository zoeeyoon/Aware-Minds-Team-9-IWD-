const questions =
[
    {
            question: "Which of the following is a common medication used to manage symptoms of dementia?",
            optionA: "Antibiotics",
            optionB: "Antidepressants",
            optionC: "Antihistamines",
            optionD: "Antacids",
            correctOption: "optionB",
          },
          {
            question: "What is the role of cognitive stimulation therapy in dementia management?",
            optionA: "To improve physical strength",
            optionB: "To slow down the progression of dementia",
            optionC: "To enhance cognitive abilities",
            optionD: "To provide emotional support",
            correctOption: "optionC",
          },
          {
            question: "Which non-pharmacological intervention has been shown to reduce agitation in individuals with dementia?",
            optionA: "Music therapy",
            optionB: "Physical restraint",
            optionC: "Isolation",
            optionD: "Bright lighting",
            correctOption: "optionA",
          },
        {
            question: "What is the primary goal of person-centered care in dementia management?",
            optionA: "To control symptoms with medication",
            optionB: "To provide physical therapy",
            optionC: "To prioritize the individual's preferences and needs",
            optionD: "To isolate the individual for safety",
            correctOption: "optionC",
          },
          {
            question: "Which form of therapy focuses on maintaining or improving physical abilities in individuals with dementia?",
            optionA: "Occupational therapy",
            optionB: "Speech therapy",
            optionC: "Art therapy",
            optionD: "Physical therapy",
            correctOption: "optionD",
          },
          {
            question: "What is the role of caregiver support programs in dementia management?",
            optionA: "To train caregivers in medical procedures",
            optionB: "To provide respite care for caregivers",
            optionC: "To limit caregiver involvement in the care process",
            optionD: "To discourage family involvement",
            correctOption: "optionB",
          },
          {
            question: "Which intervention focuses on creating a safe and stimulating environment for individuals with dementia?",
            optionA: "Validation therapy",
            optionB: "Reality orientation",
            optionC: "Behavioral therapy",
            optionD: "Environmental modification",
            correctOption: "optionD",
          },
          {
            question: "What is the purpose of palliative care in advanced stages of dementia?",
            optionA: "To cure the disease",
            optionB: "To provide emotional support to family members",
            optionC: "To focus on comfort and quality of life",
            optionD: "To delay the progression of dementia",
            correctOption: "optionC",
          },
        {
            question: "Which type of therapy focuses on helping individuals with dementia express their emotions and memories through creative activities?",
            optionA: "Music therapy",
            optionB: "Reminiscence therapy",
            optionC: "Pet therapy",
            optionD: "Aromatherapy",
            correctOption: "optionB",
          },
          {
            question: "What is the purpose of caregiver education programs in dementia management?",
            optionA: "To teach caregivers how to control challenging behaviors",
            optionB: "To provide respite care for caregivers",
            optionC: "To discourage family involvement",
            optionD: "To enhance caregivers' knowledge and skills",
            correctOption: "optionD",
          }        
];




let shuffledQuestions = [] //empty array to hold shuffled selected questions out of all available questions

function handleQuestions() { 
    //function to shuffle and push 10 questions to shuffledQuestions array
//app would be dealing with 10questions per session
    while (shuffledQuestions.length <= 9) {
        const random = questions[Math.floor(Math.random() * questions.length)]
        if (!shuffledQuestions.includes(random)) 
        {
            shuffledQuestions.push(random)
        }
    }
}


let questionNumber = 1 //holds the current question number
let playerScore = 0  //holds the player score
let wrongAttempt = 0 //amount of wrong answers picked by player
let indexNumber = 0 //will be used in displaying next question

// function for displaying next question in the array to dom
//also handles displaying players and quiz information to dom
function NextQuestion(index) {
    handleQuestions()
    const currentQuestion = shuffledQuestions[index]
    document.getElementById("question-number").innerHTML = questionNumber
    document.getElementById("player-score").innerHTML = playerScore
    document.getElementById("display-question").innerHTML = currentQuestion.question;
    document.getElementById("option-one-label").innerHTML = currentQuestion.optionA;
    document.getElementById("option-two-label").innerHTML = currentQuestion.optionB;
    document.getElementById("option-three-label").innerHTML = currentQuestion.optionC;
    document.getElementById("option-four-label").innerHTML = currentQuestion.optionD;

}


function checkForAnswer() {
    const currentQuestion = shuffledQuestions[indexNumber] //gets current Question 
    const currentQuestionAnswer = currentQuestion.correctOption //gets current Question's answer
    const options = document.getElementsByName("option"); //gets all elements in dom with name of 'option' (in this the radio inputs)
    let correctOption = null

    options.forEach((option) => {
        if (option.value === currentQuestionAnswer) {
            //get's correct's radio input with correct answer
            correctOption = option.labels[0].id
        }
    })

    //checking to make sure a radio input has been checked or an option being chosen
    if (options[0].checked === false && options[1].checked === false && options[2].checked === false && options[3].checked == false) {
        document.getElementById('option-modal').style.display = "flex"
    }

    //checking if checked radio button is same as answer
    options.forEach((option) => {
        if (option.checked === true && option.value === currentQuestionAnswer) {
            document.getElementById(correctOption).style.backgroundColor = "green"
            playerScore++ //adding to player's score
            indexNumber++ //adding 1 to index so has to display next question..
            //set to delay question number till when next question loads
            setTimeout(() => {
                questionNumber++
            }, 1000)
        }

        else if (option.checked && option.value !== currentQuestionAnswer) {
            const wrongLabelId = option.labels[0].id
            document.getElementById(wrongLabelId).style.backgroundColor = "red"
            document.getElementById(correctOption).style.backgroundColor = "green"
            wrongAttempt++ //adds 1 to wrong attempts 
            indexNumber++
            //set to delay question number till when next question loads
            setTimeout(() => {
                questionNumber++
            }, 1000)
        }
    })
}