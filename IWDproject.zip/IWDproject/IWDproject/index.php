<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Aware Minds Homerpage</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="apple-touch-icon" href="apple-touch-icon.png" />

    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!--<link rel="stylesheet" href="css/bootstrap-theme.min.css" />-->
    <link rel="stylesheet" href="css/fontAwesome.css" />
    <link rel="stylesheet" href="css/hero-slider.css" />
    <link rel="stylesheet" href="css/owl-carousel.css" />
    <link rel="stylesheet" href="css/datepicker.css" />
    <link rel="stylesheet" href="css/template-style.css" />

    <link
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800"
      rel="stylesheet"
    />

    <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
  </head>

  <body>
    <div class="popup-overlay" id="popupOverlay">
      <div class="popup-content">
          <h2>Welcome back!</h2>
          <p>Please remember to do your work oh 😊</p>
          <button id="closePopup">Close</button>
      </div>
  </div>
    <header>
      <div class="logo">
        <img src="img/logo.png" alt="Logo" style="height:35px; align-items: center;">
      </div>
      <nav>
        <ul>
          <li><a href="#" class="scroll-link" data-id="best-offer-section">About</a></li>
          <li><a href="#" class="scroll-link" data-id="events-section">Events</a></li>
          <li><a href="profile.php">Profile</a></li>
        </ul>
      </nav>
      <div class="right-links">
        <a href="logout.php">Logout</a>
      </div>
    </header>
    <section class="banner" id="top">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-8">
            <div class="left-banner-content">
              <div class="text-content">
                <h4 style="color: white">Nurturing Compassion for</h4>
                <div class="line-dec"></div>
                <h1 style="font-weight: bold;">Dementia</h1>
                <div class="white-border-button">
                  <a href="#" class="scroll-link" data-id="best-offer-section"
                    >Read More</a
                  >
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="right-banner-content">
              <div class="logo">
                <a href="index.html"><img src="img/logo.png" alt="" /></a>
              </div>
              <h2>Aware Minds</h2>
              <span>Unite to Remember: Empowering Minds, Erasing Dementia</span>
              <div class="line-dec"></div>
              <p>
                “ Our website is dedicated to spreading awareness about
                dementia, providing valuable information and resources to help
                individuals and families affected by this condition. Join us in
                raising awareness, fostering understanding, and promoting a
                dementia-inclusive society. ”
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="best-offer" id="best-offer-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-4">
            <div class="best-offer-left-content">
              <div class="icon">
                <img style="display: flex;" src="img/best-offer-icon.png" alt="" />
              </div>
              <button class="copy" id="copyLink">Share to a friend</button>
            </br>
              <h5 style="color: white; align-items: center; font-size: 15px;">
                Together, we can make a difference in the </h5> 
                <h5 style="color: white; align-items: center; font-size: 15px; padding-top: 5px;">lives of individuals and families living with
                dementia </h5>
              
            </div>
          </div>
          <div class="col-md-8">
            <div class="best-offer-right-content">
              <div class="row">
                <div class="col-md-6 col-sm-12">
                  <h2><em>About us</em></h2>
                  <p>
                    Aware Minds is a comprehensive website committed to
                    spreading awareness about dementia. Our primary goal is to
                    educate and inform individuals, families, and communities
                    about the various aspects of dementia, including its causes,
                    symptoms, and available support. Through engaging content,
                    we aim to foster understanding, reduce stigma, and promote
                    empathy towards those living with dementia. Our website
                    provides a range of resources, including articles, videos,
                    and personal stories, to help caregivers, healthcare
                    professionals, and anyone interested in dementia care. By
                    empowering individuals with knowledge, we strive to create a
                    supportive environment that enhances the well-being and
                    quality of life for people affected by dementia. Together,
                    let's build a dementia-inclusive society.
                  </p>
                  <div class="green-button">
                    <a href="#" class="scroll-link" data-id="events-section"
                      >Discover More</a
                    >
                  </div>
                </div>
                <div class="col-md-6 col-sm-12">
                  <img src="img/best-offer-image.png" alt="" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="events" id="events-section">
      <div class="content-wrapper">
        <div class="inner-container container-fluid">
          <div class="row">
            <div class="col-md-12 col-sm-12">
              <div class="section-heading">
                <div class="filter-categories">
                  <ul class="project-filter">
                    <li class="filter" data-filter="chapter">
                      <span>Reading Corner</span>
                    </li>
                    <li class="filter" data-filter="quiz">
                      <span>Quiz</span>
                    </li>
                    
                  </ul>
                </div>
              </div>
            </div>
            <div style="overflow-y: auto" class="col-md-10 col-sm-12 col-md-offset-1">
              <div class="projects-holder">
                <div class="event-list chapter">
                  <ul>
                    <li class="project-item first-child mix chapter">
                      <ul class="event-item chapter">
                        <li style="padding-bottom: 0;">
                          <div class="date">
                            <p><span>Chapter<br />1</span></p>
                          </div>
                        </li>
                        <li>
                          <h4>Chapter 1</h4>
                          <div class="chapter">
                            <div class="progress-container">
                            <div id="myBar1" class="progress-bar"></div>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="white-button">
                            <a href="Reading/chapter1.html" target="_blank" data-target="myBar1">Read</a>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li class="project-item second-child mix chapter">
                      <ul class="event-item chapter">
                        <li>
                          <div class="date">
                            <span>Chapter<br />2</span>
                          </div>
                        </li>
                        <li>
                          <h4>Chapter 2</h4>
                          <div class="chapter">
                            <div class="progress-container">
                          <div id="myBar2" class="progress-bar"></div>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="white-button">
                            <a href="Reading/chapter2.html" target="_blank" data-target="myBar2">Read</a>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li class="project-item third-child mix start chapter">
                      <ul class="event-item chapter">
                        <li>
                          <div class="date">
                            <span>Chapter<br />3</span>
                          </div>
                        </li>
                        <li>
                          <h4>Chapter 3</h4>
                          <div class="chapter">
                            <div class="progress-container">
                          <div id="myBar3" class="progress-bar"></div>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="white-button">
                            <a href="Reading/chapter3.html" target="_blank" data-target="myBar3">Read</a>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li class="project-item fourth-child mix chapter">
                      <ul class="event-item chapter">
                        <li>
                          <div class="date">
                            <span>Chapter<br />4</span>
                          </div>
                        </li>
                        <li>
                          <h4>Chapter 4</h4>
                          <div class="chapter">
                            <div class="chapter">
                              <div class="progress-container">
                            <div id="myBar4" class="progress-bar"></div>
                              </div>
                          </div>
                        </li>
                        <li>
                          <div class="white-button">
                           <a href="Reading/chapter4.html" target="_blank" data-target="myBar4">Read</a>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li class="project-item fivth-child mix start chapter">
                      <ul class="event-item chapter">
                        <li>
                          <div class="date">
                            <span>Chapter<br />5</span>
                          </div>
                        </li>
                        <li>
                          <h4>Chapter 5</h4>
                          <div class="chapter">
                            <div class="chapter">
                              <div class="progress-container">
                             <div id="myBar5" class="progress-bar"></div>
                              </div>
                          </div>
                        </li>
                        <li>
                          <div class="white-button">
                            <a href="Reading/chapter5.html" target="_blank" data-target="myBar5">Read</a>
                          </div>
                        </li>
                      </ul>
                    </li>
                <!--  </ul> -->

            
              <div class="event-list quiz">
                <ul class="event-list quiz">
                    <li class="project-item first-child mix quiz">
                      <ul class="event-item quiz">
                        <li>
                          <div class="date">
                            <p><span>Quiz<br />1</span></p>
                          </div>
                        </li>
                        <li>
                          <h4>Quiz 1</h4>
                          <div class="quiz">
                            <div class="progress-container">
                         <div id="myBar6" class="progress-bar"></div>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="white-button">
                            <a href="Quiz/chapter1.html" target="_blank" data-target="myBar6">Start</a>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li class="project-item second-child mix quiz">
                      <ul class="event-item quiz">
                        <li>
                          <div class="date">
                            <span>Quiz<br />2</span>
                          </div>
                        </li>
                        <li>
                          <h4>Quiz 2</h4>
                          <div class="quiz">
                            <div class="progress-container">
                            <div id="myBar7" class="progress-bar"></div>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="white-button">
                            <a href="Quiz/chapter2.html" target="_blank" data-target="myBar7" onclick>Start</a>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li class="project-item third-child mix start quiz">
                      <ul class="event-item quiz">
                        <li>
                          <div class="date">
                            <span>Quiz<br />3</span>
                          </div>
                        </li>
                        <li>
                          <h4>Quiz 3</h4>
                          <div class="quiz">
                            <div class="progress-container">
                            <div id="myBar8" class="progress-bar"></div>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="white-button">
                            <a href="Quiz/chapter3.html" target="_blank" data-target="myBar8">Start</a>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li class="project-item fourth-child mix quiz">
                      <ul class="event-item quiz">
                        <li>
                          <div class="date">
                            <span>Quiz<br />4</span>
                          </div>
                        </li>
                        <li>
                          <h4>Quiz 4</h4>
                          <div class="quiz">
                            <div class="progress-container">
                            <div id="myBar9" class="progress-bar"></div>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="white-button">
                            <a href="Quiz/chapter4.html" target="_blank" data-target="myBar9">Start</a>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li class="project-item fivth-child mix start quiz">
                      <ul class="event-item quiz">
                        <li>
                          <div class="date">
                            <span>Quiz<br />5</span>
                          </div>
                        </li>
                        <li>
                          <h4>Quiz 5</h4>
                          <div class="quiz">
                            <div class="progress-container">
                            <div id="myBar10" class="progress-bar"></div>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="white-button">
                            <a href="Quiz/chapter5.html" target="_blank" data-target="myBar10">Start</a>
                          </div>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="testimonial" id="testimonial-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-4">
            <div class="testimonial-image"></div>
          </div>
          <div class="col-md-8">
            <div id="owl-testimonial" class="owl-carousel owl-theme">
              <div class="item col-md-12">
                <img style=" border-radius: 50%; overflow: hidden" src="img/Zoee.jpeg" alt="Yoon Hua Tong" />
                <span>Web Developer</span>
                <h4>Yoon Hua Tong</h4>
                <br />
                <p>
                  <em>"</em>Creating a website about dementia sends a powerful
                  message of compassion and understanding. It educates society
                  about the challenges faced by individuals living with dementia
                  and fosters empathy, ultimately working towards building a
                  more inclusive and supportive community.<em>"</em>
                </p>
              </div>
              <div class="item col-md-12">
                <img style=" border-radius: 50%; overflow: hidden" src="img/Salman.jpeg" alt="Salman" />
                <span>Web Developer</span>
                <h4>Salman Mohammad Usman Nalband</h4>
                <br />
                <p>
                  <em>"</em>A website dedicated to dementia sheds light on an
                  often misunderstood condition, offering a platform for
                  education and support. It sends a message of hope, providing
                  resources and guidance to empower caregivers, families, and
                  individuals impacted by dementia.<em>"</em>
                </p>
              </div>
              <div class="item col-md-12">
                <img style=" border-radius: 50%; overflow: hidden" src="img/JiehWei.jpeg" alt="Jieh Wei" />
                <span>Web Developer</span>
                <h4>Liew Jieh Wei</h4>
                <br />
                <p>
                  <em>"</em>By creating a website about dementia, we are
                  spreading awareness and breaking down the stigma associated
                  with the condition. It conveys a message of unity, encouraging
                  collaboration and collective action in advocating for improved
                  dementia care, research, and public policy.<em>"</em>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="services" id="services-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">
            <div
              class="flip-container"
              ontouchstart="this.classList.toggle('hover');"
            >
              <div class="flipper first-service">
                <div class="front">
                  <div class="icon">
                    <img  style="display: flex;" src="img/heart-icon.png" alt="" />
                  </div>
                  <h4>Fun Fact</h4>
                </div>
                <div class="back">
                  <p>
                    Dementia is not a normal part of aging; it is a
                    neurodegenerative condition. While age is a risk factor, not
                    all older adults develop dementia, and it can also affect
                    younger individuals.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div
              class="flip-container"
              ontouchstart="this.classList.toggle('hover');"
            >
              <div class="flipper second-service">
                <div class="front">
                  <div class="icon">
                    <img  style="  display: flex;" src="img/home-icon.png" alt="" />
                  </div>
                  <h4>Fun Fact</h4>
                </div>
                <div class="back">
                  <p>
                    The term "dementia" originates from the Latin word "demens,"
                    which means "without mind." However, people living with
                    dementia still have moments of clarity, emotions, and the
                    ability to connect with others.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div
              class="flip-container"
              ontouchstart="this.classList.toggle('hover');"
            >
              <div class="flipper third-service">
                <div class="front">
                  <div class="icon">
                    <img  style="  display: flex;" src="img/revision-icon.png" alt="" />
                  </div>
                  <h4>Fun Fact</h4>
                </div>
                <div class="back">
                  <p>
                    Musical memories can often remain intact for individuals
                    with dementia, even in advanced stages. Music therapy has
                    shown to be beneficial, stimulating memories, reducing
                    anxiety, and improving overall well-being.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div
              class="flip-container"
              ontouchstart="this.classList.toggle('hover');"
            >
              <div class="flipper fourth-service">
                <div class="front">
                  <div class="icon">
                    <img  style="  display: flex;" src="img/chat-icon.png" alt="" />
                  </div>
                  <h4>Fun Fact</h4>
                </div>
                <div class="back">
                  <p>
                    Dementia affects not only memory but also various cognitive
                    functions such as language, attention, and problem-solving.
                    This can lead to interesting linguistic phenomena, such as
                    using neologisms or substituting familiar words with
                    unrelated terms, known as "semantic paraphasia."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <footer>
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <p>
              <a id="copylink1" style="color:#265d60;">Tell a friend. </a>Together, we can make a
              difference in the lives of individuals and families living with
              dementia
            </p>
            <!--<button class="copy" id="copylink1">Share to a friend</button>-->
          </div>
        </div>
      </div>
    </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>
      window.jQuery ||
        document.write(
          '<script src="js/vendor/jquery-1.11.2.min.js"><\/script>'
        );
    </script>

    <!--<script src="js/vendor/bootstrap.min.js"></script>-->

    <script src="js/datepicker.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

    <script type="text/javascript">
      $(document).ready(function () {
        // navigation click actions
        $(".scroll-link").on("click", function (event) {
          event.preventDefault();
          var sectionID = $(this).attr("data-id");
          scrollToID("#" + sectionID, 750);
        });
        // scroll to top action
        $(".scroll-top").on("click", function (event) {
          event.preventDefault();
          $("html, body").animate({ scrollTop: 0 }, "slow");
        });
        // mobile nav toggle
        $("#nav-toggle").on("click", function (event) {
          event.preventDefault();
          $("#main-nav").toggleClass("open");
        });
      });
      // scroll function
      function scrollToID(id, speed) {
        var offSet = 0;
        var targetOffset = $(id).offset().top - offSet;
        var mainNav = $("#main-nav");
        $("html,body").animate({ scrollTop: targetOffset }, speed);
        if (mainNav.hasClass("open")) {
          mainNav.css("height", "1px").removeClass("in").addClass("collapse");
          mainNav.removeClass("open");
        }
      }
      if (typeof console === "undefined") {
        console = {
          log: function () {},
        };
      }
      const toggleButton = document.getElementById('toggleButton');
      const elementGroup = document.getElementById("event-list quiz");

toggleButton.addEventListener('click', function() {
  elementGroup.classList.toggle('hidden');
});
    </script>
  </body>
</html>