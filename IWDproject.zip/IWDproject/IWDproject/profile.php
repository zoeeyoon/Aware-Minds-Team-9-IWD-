<?php
session_start();

// Check if the user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Get the logged-in user's name from the session
$userName = $_SESSION["username"];
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #357f83;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100px;
        }
        .profile-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            max-width: 1200px;
            margin: 20px;
        }
        .box {
            width: 300px;
            margin: 10px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .box:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .user-info-box {
            height: 300px;
            width: 1020px;
            margin: 10px;
        }
     /*   .progress-info-box {  
            height: 300px;
            width: 300px;
            margin: 10px;
        }
        .quiz-info-box{
            height: 300px;
            width: 300px;
            margin: 10px; 
        } */
        h2 {
            margin: 0 0 20px;
            color: #333;
        }
        p {
            color: #777;
        }
        .certificate-btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            background-color: #357f83;
            color: #fff;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .certificate-btn:hover {
            background-color: #dbaa48;
        }
        .logout-btn {
            display: block;
            margin-top: 20px;
            color: #357f83;
            text-decoration: none;
            transition: color 0.3s;
        }
        .logout-btn:hover {
            color: #dbaa48;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <div class="box user-info-box">
            <h2>User Information</h2>
    </br>
            <p style="font-size: 20px;">Name: <?php echo $userName; ?></p>
    </br></br>
            <a href="cert.php" class="certificate-btn">View Certificate</a>
            <a href="reset_pw.php" class="logout-btn">Reset Password</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    <!--    <div class="box progress-info-box">
            <h2>Progress</h2>
            Insert pie chart code here
        </div>
        <div class="box progress-info-box">
            <h2>Chapter Completion</h2>
             Insert chapter completion status here 
        </div>
        <div class="box quiz-info-box">
            <h2>Quiz Completion</h2>
            Insert quiz completion status here --> 
        </div>
    </div>
</body>
</html>
</body>
</html>