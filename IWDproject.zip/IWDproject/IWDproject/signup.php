<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate username
    if (isset($_POST["signup_username"])) {
        $username = trim($_POST["signup_username"]);
        if (empty($username)) {
            $username_err = "Please enter a username.";
        } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            $username_err = "Username can only contain letters, numbers, and underscores.";
        } else {
            // Prepare a select statement
            $sql = "SELECT id FROM dementia_users WHERE username = ?";
            
            if ($stmt = mysqli_prepare($link, $sql)) {
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, "s", $param_username);
                
                // Set parameters
                $param_username = $username;
                
                // Attempt to execute the prepared statement
                if (mysqli_stmt_execute($stmt)) {
                    /* store result */
                    mysqli_stmt_store_result($stmt);
                    
                    if (mysqli_stmt_num_rows($stmt) == 1) {
                        $username_err = "This username is already taken.";
                    }
                } else {
                    echo "Oops! Something went wrong. Please try again later.";
                }
    
                // Close statement
                mysqli_stmt_close($stmt);
            }
        }
    }

    // Validate password
    if (isset($_POST["signup_password"])) {
        $password = trim($_POST["signup_password"]);
        if (empty($password)) {
            $password_err = "Please enter a password.";
        } elseif (strlen($password) < 6) {
            $password_err = "Password must have at least 6 characters.";
        }
    }

    // Validate confirm password
    if (isset($_POST["confirm_password"])) {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($confirm_password)) {
            $confirm_password_err = "Please confirm password.";
        } elseif ($password !== $confirm_password) {
            $confirm_password_err = "Password did not match.";
        }
    }

    // Check input errors before inserting in database
    if (empty($username_err) && empty($password_err) && empty($confirm_password_err)) {
        // Prepare an insert statement
        $sql = "INSERT INTO dementia_users (username, password) VALUES (?, ?)";
        
        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                // Redirect to login page
                header("location: login.php");
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8" />
    <title>Signup Form | CodingNepal</title>
    <link rel="stylesheet" href="style.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
    <div class="wrapper">
        <div class="title-text">
            <div class="title signup">SIGNUP</div>
        </div>
        <div class="form-container">
            <div class="form-inner">
                <!-- SIGNUP -->
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" class="signup" method="POST">
                    <div class="field">
                        <input type="text" placeholder="Username" name="signup_username" required />
                        <span class="invalid-feedback"><?php echo $username_err; ?></span>
                    </div>
                    <div class="field">
                        <input type="password" placeholder="Password" name="signup_password" required />
                        <span class="invalid-feedback"><?php echo $password_err; ?></span>
                    </div>
                    <div class="field">
                        <input type="password" placeholder="Confirm password" name="confirm_password" required />
                        <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
                    </div>
                    <div class="field btn">
                        <div class="btn-layer"></div>
                        <input type="submit" value="Signup" />
                    </div>
                    <div class="signup-link">
                        Already have an account? <a href="login.php">Login here</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>